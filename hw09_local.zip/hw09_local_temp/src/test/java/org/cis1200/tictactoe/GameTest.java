package org.cis1200.tictactoe;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * You can use this file (and others) to test your
 * implementation.
 */

public class GameTest {

    @Test
    public void test() {
        assertNotEquals("CIS 120", "CIS 160");
    }

}
